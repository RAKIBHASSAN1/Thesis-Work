package com.example.myapplication;

class MyViewHolder {
}
